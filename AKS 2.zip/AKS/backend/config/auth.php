<?php
// config/auth.php
// Shared auth helpers. Require this in any controller that needs
// session checks or password rules, instead of rewriting the logic.

function start_secure_session() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Use this at the top of ANY admin-only API endpoint
function require_admin_login() {
    start_secure_session();
    if (!isset($_SESSION['admin_id'])) {
        send_error("Unauthorized. Please log in.", 401);
    }
}

// Use this at the top of ANY user-only API endpoint
function require_user_login() {
    start_secure_session();
    if (!isset($_SESSION['user_id'])) {
        send_error("Unauthorized. Please log in.", 401);
    }
}

// Blocks access to everything except the change-password endpoint
// until the user has changed their temporary password.
function block_if_first_login() {
    start_secure_session();
    if (isset($_SESSION['first_login']) && $_SESSION['first_login'] == 1) {
        send_error("Password change required before continuing.", 403);
    }
}

// Centralized password complexity rule — reuse this everywhere
// a password is created or changed, so the rule never drifts.
function is_password_strong($password) {
    if (strlen($password) < 8) return false;
    if (!preg_match('/[A-Z]/', $password)) return false;
    if (!preg_match('/[a-z]/', $password)) return false;
    if (!preg_match('/[0-9]/', $password)) return false;
    if (!preg_match('/[\W_]/', $password)) return false; // special char
    return true;
}

// Generates a random temporary password that ALSO satisfies the
// complexity rule above (the original md5(rand()) approach doesn't
// guarantee uppercase/lowercase/number/symbol every time).
function generate_temp_password($length = 10) {
    $upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    $lower = "abcdefghijkmnpqrstuvwxyz";
    $number = "23456789";
    $symbol = "!@#$%&*";

    $password = $upper[random_int(0, strlen($upper) - 1)]
              . $lower[random_int(0, strlen($lower) - 1)]
              . $number[random_int(0, strlen($number) - 1)]
              . $symbol[random_int(0, strlen($symbol) - 1)];

    $all = $upper . $lower . $number . $symbol;
    for ($i = strlen($password); $i < $length; $i++) {
        $password .= $all[random_int(0, strlen($all) - 1)];
    }

    return str_shuffle($password);
}
