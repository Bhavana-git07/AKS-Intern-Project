<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$result =
$conn->query(
"SELECT compliance_percentage
FROM assessments
WHERE assessment_id=$assessment_id"
);

$data =
$result->fetch_assoc();

$percentage =
$data['compliance_percentage'];

$status = '';

if($percentage >= 80){
    $status = 'Ready';
}
elseif($percentage >= 50){
    $status = 'Partially Ready';
}
else{
    $status = 'Not Ready';
}

echo json_encode([
    "compliance_percentage"=>$percentage,
    "readiness"=>$status
]);
?>