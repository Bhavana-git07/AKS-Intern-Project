<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$assessment =
$conn->query(
"SELECT *
FROM assessments
WHERE assessment_id=$assessment_id"
)->fetch_assoc();

$current = $assessment['current_framework_id'];
$target = $assessment['target_framework_id'];

$target_controls =
$conn->query(
"SELECT c.control_id,
cm.master_control_id
FROM controls c
JOIN control_mappings cm
ON c.control_id=cm.control_id
WHERE c.framework_id=$target"
);

$total = 0;
$matched = 0;

while($row = $target_controls->fetch_assoc())
{
    $total++;

    $master = $row['master_control_id'];
    $control = $row['control_id'];

    $exists =
    $conn->query(
    "SELECT *
    FROM controls c
    JOIN control_mappings cm
    ON c.control_id=cm.control_id
    WHERE c.framework_id=$current
    AND cm.master_control_id=$master"
    );

    $status = "Missing";

    if($exists->num_rows > 0)
    {
        $status = "Matched";
        $matched++;
    }

    $stmt =
    $conn->prepare(
    "INSERT INTO assessment_controls
    (assessment_id,control_id,status)
    VALUES (?,?,?)"
    );

    $stmt->bind_param(
    "iis",
    $assessment_id,
    $control,
    $status
    );

    $stmt->execute();
}

$percentage = 0;

if($total > 0)
{
    $percentage = ($matched/$total)*100;
}

$conn->query(
"UPDATE assessments
SET compliance_percentage=$percentage
WHERE assessment_id=$assessment_id"
);

echo json_encode([
    "matched_controls"=>$matched,
    "missing_controls"=>$total-$matched,
    "compliance_percentage"=>$percentage
]);
?>