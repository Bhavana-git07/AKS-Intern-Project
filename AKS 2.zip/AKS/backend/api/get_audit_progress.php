<?php
include '../config/database.php';

$audit_id = $_GET['audit_id'];

$result = $conn->query(
    "SELECT progress, status
     FROM audits
     WHERE audit_id = $audit_id"
);

$row = $result->fetch_assoc();

echo json_encode($row);
?>