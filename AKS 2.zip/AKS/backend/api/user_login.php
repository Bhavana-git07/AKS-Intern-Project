<?php
// api/user_login.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if (empty($email) || empty($password)) {
    send_error("Email and password are required.");
}

$stmt = $conn->prepare("SELECT user_id, company_id, full_name, email, password, role, first_login FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    send_error("Invalid email or password.", 401);
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user['password'])) {
    send_error("Invalid email or password.", 401);
}

start_secure_session();
$_SESSION['user_id'] = $user['user_id'];
$_SESSION['company_id'] = $user['company_id'];
$_SESSION['first_login'] = $user['first_login'];

send_success("Login successful.", [
    "user_id" => $user['user_id'],
    "full_name" => $user['full_name'],
    "role" => $user['role'],
    "first_login" => (bool)$user['first_login'] // frontend uses this to redirect to "change password" page
]);
