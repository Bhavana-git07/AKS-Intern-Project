<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$checklist_id = $data['checklist_id'];
$is_completed = $data['is_completed'];

/* Update checklist item */
$stmt = $conn->prepare(
    "UPDATE audit_checklist
     SET is_completed = ?
     WHERE checklist_id = ?"
);

$stmt->bind_param("ii", $is_completed, $checklist_id);
$stmt->execute();

/* Get audit_id */
$result = $conn->query(
    "SELECT audit_id
     FROM audit_checklist
     WHERE checklist_id = $checklist_id"
);

$row = $result->fetch_assoc();
$audit_id = $row['audit_id'];

/* Total items */
$total = $conn->query(
    "SELECT COUNT(*) AS total
     FROM audit_checklist
     WHERE audit_id = $audit_id"
)->fetch_assoc()['total'];

/* Completed items */
$completed = $conn->query(
    "SELECT COUNT(*) AS completed
     FROM audit_checklist
     WHERE audit_id = $audit_id
     AND is_completed = 1"
)->fetch_assoc()['completed'];

$progress = ($completed / $total) * 100;

/* Update progress */
$stmt2 = $conn->prepare(
    "UPDATE audits
     SET progress = ?
     WHERE audit_id = ?"
);

$stmt2->bind_param("ii", $progress, $audit_id);
$stmt2->execute();

/* If completed */
if ($progress == 100) {
    $conn->query(
        "UPDATE audits
         SET status = 'Completed'
         WHERE audit_id = $audit_id"
    );
}

echo json_encode([
    "success" => true,
    "progress" => $progress
]);
?>