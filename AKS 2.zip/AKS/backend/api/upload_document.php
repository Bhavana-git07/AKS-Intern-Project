<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $company_id = $_POST['company_id'];
    $framework = isset($_POST['framework']) ? $_POST['framework'] : null;
    $control_code = isset($_POST['control_code']) ? $_POST['control_code'] : null;

    $folder = "../uploads/";

    // Ensure uploads directory exists
    if (!file_exists($folder)) {
        mkdir($folder, 0777, true);
    }

    $file_name = time() . "_" . $_FILES['document']['name'];

    $file_path = $folder . $file_name;

    if (move_uploaded_file(
        $_FILES['document']['tmp_name'],
        $file_path
    )) {

        $stmt = $conn->prepare(
            "INSERT INTO documents
            (company_id, file_name, file_path, framework, control_code)
            VALUES (?, ?, ?, ?, ?)"
        );

        $stmt->bind_param(
            "issss",
            $company_id,
            $file_name,
            $file_path,
            $framework,
            $control_code
        );

        $stmt->execute();

        echo json_encode([
            "success"=>true
        ]);
    } else {
        echo json_encode([
            "success"=>false,
            "message"=>"Failed to move uploaded file."
        ]);
    }
}
?>