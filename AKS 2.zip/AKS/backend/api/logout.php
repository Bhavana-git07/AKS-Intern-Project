<?php
// api/logout.php
require_once '../config/response.php';
require_once '../config/auth.php';

start_secure_session();
$_SESSION = [];
session_destroy();

send_success("Logged out successfully.");
