<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$result =
$conn->query(
"SELECT
assessment_id,
compliance_percentage
FROM assessments
WHERE assessment_id=$assessment_id"
);

$assessment =
$result->fetch_assoc();

$matched =
$conn->query(
"SELECT COUNT(*)
AS total
FROM assessment_controls
WHERE assessment_id=$assessment_id
AND status='Matched'"
)->fetch_assoc();

$missing =
$conn->query(
"SELECT COUNT(*)
AS total
FROM assessment_controls
WHERE assessment_id=$assessment_id
AND status='Missing'"
)->fetch_assoc();

echo json_encode([
    "assessment_id"=>$assessment_id,
    "matched_controls"=>$matched['total'],
    "missing_controls"=>$missing['total'],
    "compliance_percentage"=>$assessment['compliance_percentage']
]);
?>