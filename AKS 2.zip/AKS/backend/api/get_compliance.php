<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$result =
$conn->query(
"SELECT compliance_percentage
FROM assessments
WHERE assessment_id=$assessment_id"
);

echo json_encode(
$result->fetch_assoc()
);
?>