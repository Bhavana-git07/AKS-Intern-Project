<?php
require('../fpdf/fpdf.php');
include('../config/database.php');

$assessment_id = $_GET['assessment_id'];

/* ================= DATA ================= */

$assessment = $conn->query("
    SELECT * FROM assessments
    WHERE assessment_id = $assessment_id
")->fetch_assoc();

$percentage = $assessment['compliance_percentage'] ?? 0;

$matched = $conn->query("
    SELECT COUNT(*) AS total
    FROM assessment_controls
    WHERE assessment_id=$assessment_id
    AND status='Matched'
")->fetch_assoc()['total'] ?? 0;

$missing = $conn->query("
    SELECT COUNT(*) AS total
    FROM assessment_controls
    WHERE assessment_id=$assessment_id
    AND status='Missing'
")->fetch_assoc()['total'] ?? 0;

/* ================= RISK ENGINE ================= */

if ($percentage >= 85) {
    $risk = "LOW RISK";
    $riskColor = [0, 120, 0];
} elseif ($percentage >= 60) {
    $risk = "MEDIUM RISK";
    $riskColor = [255, 140, 0];
} else {
    $risk = "HIGH RISK";
    $riskColor = [200, 0, 0];
}

/* ================= PDF CLASS ================= */

class PDF extends FPDF {

    function Header() {

        // Dark top bar
        $this->SetFillColor(20, 20, 20);
        $this->Rect(0, 0, 210, 22, 'F');

        $this->SetFont('Arial','B',14);
        $this->SetTextColor(255,255,255);
        $this->SetY(6);
        $this->Cell(0,6,'ENTERPRISE COMPLIANCE AUDIT REPORT',0,1,'C');

        $this->SetFont('Arial','',9);
        $this->Cell(0,6,'Automated Risk & Control Assessment System',0,1,'C');

        $this->Ln(8);
        $this->SetTextColor(0,0,0);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial','I',8);
        $this->SetTextColor(120,120,120);
        $this->Cell(0,10,'Confidential | Page '.$this->PageNo().'/{nb}',0,0,'C');
    }
}

/* ================= INIT ================= */

$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

/* ================= META ================= */

$pdf->SetFont('Arial','',10);
$pdf->Cell(0,6,'Report Generated: '.date('d M Y - H:i:s'),0,1,'R');

$pdf->Ln(3);

/* ================= EXECUTIVE SUMMARY ================= */

$pdf->SetFont('Arial','B',14);
$pdf->Cell(0,8,'EXECUTIVE SUMMARY',0,1);

$pdf->SetFont('Arial','',11);

$summary = "This report presents an automated compliance assessment showing control coverage, gap analysis, and audit readiness status for the selected framework.";

$pdf->MultiCell(0,6,$summary);

$pdf->Ln(4);

/* ================= KPI DASHBOARD ================= */

$pdf->SetFont('Arial','B',11);
$pdf->SetFillColor(245,245,245);

$pdf->Cell(63,20,"COMPLIANCE\n".$percentage.'%',1,0,'C',true);
$pdf->Cell(63,20,"MATCHED\n".$matched,1,0,'C',true);
$pdf->Cell(64,20,"MISSING\n".$missing,1,1,'C',true);

$pdf->Ln(3);

/* ================= RISK LABEL ================= */

$pdf->SetFont('Arial','B',14);
$pdf->SetTextColor($riskColor[0], $riskColor[1], $riskColor[2]);

$pdf->Cell(190,10,$risk,1,1,'C');

$pdf->SetTextColor(0,0,0);

$pdf->Ln(6);

/* ================= GAP ANALYSIS ================= */

$pdf->SetFont('Arial','B',13);
$pdf->Cell(0,8,'CONTROL GAP ANALYSIS MATRIX',0,1);

$pdf->Ln(2);

/* TABLE HEADER */
$pdf->SetFont('Arial','B',10);
$pdf->SetFillColor(230,230,230);

$pdf->Cell(90,8,'Control Name',1,0,'C',true);
$pdf->Cell(40,8,'Code',1,0,'C',true);
$pdf->Cell(60,8,'Status',1,1,'C',true);

/* TABLE DATA */
$pdf->SetFont('Arial','',9);

$controls = $conn->query("
    SELECT c.control_name, c.control_code, ac.status
    FROM assessment_controls ac
    JOIN controls c ON ac.control_id = c.control_id
    WHERE ac.assessment_id = $assessment_id
");

while ($row = $controls->fetch_assoc()) {

    // auto page break safety
    if ($pdf->GetY() > 250) {
        $pdf->AddPage();
    }

    $pdf->Cell(90,7,$row['control_name'],1);
    $pdf->Cell(40,7,$row['control_code'],1,'C');

    if ($row['status'] == 'Matched') {
        $pdf->SetTextColor(0,140,0);
    } else {
        $pdf->SetTextColor(200,0,0);
    }

    $pdf->Cell(60,7,$row['status'],1,1,'C');

    $pdf->SetTextColor(0,0,0);
}

/* ================= FOOT NOTE SECTION ================= */

$pdf->Ln(5);
$pdf->SetFont('Arial','I',9);
$pdf->SetTextColor(100,100,100);

$pdf->MultiCell(0,5,
"Note: This report is system-generated and based on automated control mapping logic. "
."It should be validated during manual audit review.");

$pdf->Output();
?>