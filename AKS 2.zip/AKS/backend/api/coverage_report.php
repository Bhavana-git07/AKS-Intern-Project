<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$assessment =
$conn->query(
"SELECT *
FROM assessments
WHERE assessment_id=$assessment_id"
)->fetch_assoc();

$framework =
$assessment['target_framework_id'];

$total =
$conn->query(
"SELECT COUNT(*) AS total
FROM controls
WHERE framework_id=$framework"
)->fetch_assoc();

$covered =
$conn->query(
"SELECT COUNT(*) AS total
FROM assessment_controls
WHERE assessment_id=$assessment_id
AND status='Matched'"
)->fetch_assoc();

$percentage = 0;

if($total['total'] > 0){
    $percentage =
    ($covered['total']/$total['total'])*100;
}

echo json_encode([
    "total_controls"=>$total['total'],
    "covered_controls"=>$covered['total'],
    "coverage_percentage"=>$percentage
]);
?>