<?php
// backend/api/audit_logs_list.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

require_admin_login();

$user_type = $_GET['user_type'] ?? '';
$search = $_GET['search'] ?? '';

$sql = "SELECT log_id, user_id, user_type, action, ip_address, created_at FROM audit_logs WHERE 1=1";
$params = [];
$types = "";

if (!empty($user_type)) {
    $sql .= " AND user_type = ?";
    $params[] = $user_type;
    $types .= "s";
}

if (!empty($search)) {
    $sql .= " AND (action LIKE ? OR ip_address LIKE ?)";
    $searchWild = "%" . $search . "%";
    $params[] = $searchWild;
    $params[] = $searchWild;
    $types .= "ss";
}

$sql .= " ORDER BY created_at DESC LIMIT 100";

$stmt = $conn->prepare($sql);
if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}
$stmt->execute();
$result = $stmt->get_result();

$logs = [];
while ($row = $result->fetch_assoc()) {
    $logs[] = $row;
}

send_success("Audit logs loaded successfully.", $logs);
?>
