<?php
// backend/api/verify_otp.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

// CSRF check
validate_request_csrf();

$input = json_decode(file_get_contents("php://input"), true);
$otp_code = trim($input['otp_code'] ?? '');

if (empty($otp_code)) {
    send_error("OTP code is required.");
}

start_secure_session();

if (!isset($_SESSION['temp_login'])) {
    send_error("Session expired. Please log in again.", 400);
}

$temp = $_SESSION['temp_login'];
$user_id = $temp['id'];
$user_type = $temp['type'];

// Check database for active OTP
$stmt = $conn->prepare("
    SELECT otp_id, otp_code, expires_at, attempts, is_verified 
    FROM mfa_otp 
    WHERE user_id = ? AND user_type = ? AND is_verified = 0 
    ORDER BY created_at DESC LIMIT 1
");
$stmt->bind_param("is", $user_id, $user_type);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    send_error("No active OTP code generated. Please request a new one.", 400);
}

$mfa = $result->fetch_assoc();

// Check if expired
if (strtotime($mfa['expires_at']) < time()) {
    send_error("MFA OTP code has expired. Please request a new one.", 400);
}

// Check maximum attempts limit
if ($mfa['attempts'] >= 3) {
    send_error("Too many incorrect attempts. Please log in again.", 400);
}

// Compare codes
if ($mfa['otp_code'] !== $otp_code) {
    // Increment attempts
    $new_attempts = $mfa['attempts'] + 1;
    $upStmt = $conn->prepare("UPDATE mfa_otp SET attempts = ? WHERE otp_id = ?");
    $upStmt->bind_param("ii", $new_attempts, $mfa['otp_id']);
    $upStmt->execute();

    send_error("Invalid OTP code. Please try again. (Remaining attempts: " . (3 - $new_attempts) . ")", 401);
}

// Mark OTP as verified
$verifyStmt = $conn->prepare("UPDATE mfa_otp SET is_verified = 1 WHERE otp_id = ?");
$verifyStmt->bind_param("i", $mfa['otp_id']);
$verifyStmt->execute();

// Establish real authenticated session
if ($user_type === 'admin') {
    $_SESSION['admin_id'] = $user_id;
    $_SESSION['admin_name'] = $temp['name'];
    
    log_audit_activity("Admin sign-in successful via MFA", $user_id, 'admin');

    send_success("MFA verification successful. Redirecting...", [
        "role" => "admin",
        "first_login" => false,
        "name" => $temp['name'],
        "email" => $temp['email']
    ]);
} else {
    $_SESSION['user_id'] = $user_id;
    $_SESSION['company_id'] = $temp['company_id'];
    $_SESSION['first_login'] = $temp['first_login'];

    log_audit_activity("User sign-in successful via MFA", $user_id, 'user');

    send_success("MFA verification successful. Redirecting...", [
        "role" => $temp['role'],
        "first_login" => (bool)$temp['first_login'],
        "name" => $temp['name'],
        "email" => $temp['email']
    ]);
}

// Clear temporary session
unset($_SESSION['temp_login']);
?>
