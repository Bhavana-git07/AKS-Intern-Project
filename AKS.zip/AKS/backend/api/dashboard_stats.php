<?php
// api/dashboard_stats.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

start_secure_session();

// Initialize stats array
$stats = [
    "total_companies" => 0,
    "total_frameworks" => 4, // Default fallback
    "total_controls" => 0,
    "total_documents" => 0,
    "pending_assessments" => 0,
    "high_risk_items" => 0,
    "average_compliance" => 0,
    "recent_activities" => [],
    "pie_chart" => [
        "satisfied" => 0,
        "gaps" => 0
    ],
    "bar_chart" => [
        "PayNet TPA" => 0,
        "BNM RMiT" => 0,
        "MAS TRM" => 0,
        "NACSA NC-II" => 0
    ],
    "compliance_trend" => []
];

// 1. Total Companies
$res = $conn->query("SELECT COUNT(*) as count FROM companies");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["total_companies"] = (int)$row["count"];
}

// 2. Total Frameworks
$res = $conn->query("SELECT COUNT(*) as count FROM frameworks");
if ($res) {
    $row = $res->fetch_assoc();
    if ((int)$row["count"] > 0) {
        $stats["total_frameworks"] = (int)$row["count"];
    }
}

// 3. Total Controls
$res = $conn->query("SELECT COUNT(*) as count FROM controls");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["total_controls"] = (int)$row["count"];
}

// 4. Total Documents
$res = $conn->query("SELECT COUNT(*) as count FROM documents");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["total_documents"] = (int)$row["count"];
}

// 5. Pending Assessments (compliance < 100)
$res = $conn->query("SELECT COUNT(*) as count FROM assessments WHERE compliance_percentage < 100");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["pending_assessments"] = (int)$row["count"];
}

// 6. High Risk Items (Missing controls in assessment_controls)
$res = $conn->query("SELECT COUNT(*) as count FROM assessment_controls WHERE status = 'Missing'");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["high_risk_items"] = (int)$row["count"];
}

// 7. Average Compliance
$res = $conn->query("SELECT AVG(compliance_percentage) as avg_compliance FROM assessments");
if ($res) {
    $row = $res->fetch_assoc();
    $stats["average_compliance"] = $row["avg_compliance"] ? round((float)$row["avg_compliance"], 1) : 0;
}

// 8. Recent Activities (from activity_logs or audit_logs if created)
$activities = [];
$res = $conn->query("SELECT action, created_at FROM activity_logs ORDER BY created_at DESC LIMIT 5");
if (!$res) {
    // Try audit_logs if activity_logs is not preferred
    $res = $conn->query("SELECT action, created_at FROM audit_logs ORDER BY created_at DESC LIMIT 5");
}
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $activities[] = [
            "action" => $row["action"],
            "created_at" => $row["created_at"]
        ];
    }
}
$stats["recent_activities"] = $activities;

// 9. Pie Chart (Satisfied vs Gaps)
$res = $conn->query("SELECT status, COUNT(*) as qty FROM assessment_controls GROUP BY status");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        if ($row["status"] === 'Matched') {
            $stats["pie_chart"]["satisfied"] = (int)$row["qty"];
        } else {
            $stats["pie_chart"]["gaps"] += (int)$row["qty"];
        }
    }
}

// 10. Bar Chart (Framework-wise Average Compliance)
$res = $conn->query("SELECT target_framework_id, AVG(compliance_percentage) as avg_pct FROM assessments GROUP BY target_framework_id");
if ($res) {
    $fw_map = [
        1 => "PayNet TPA",
        2 => "BNM RMiT",
        3 => "MAS TRM",
        4 => "NACSA NC-II"
    ];
    while ($row = $res->fetch_assoc()) {
        $fw_id = (int)$row["target_framework_id"];
        if (isset($fw_map[$fw_id])) {
            $stats["bar_chart"][$fw_map[$fw_id]] = round((float)$row["avg_pct"], 1);
        }
    }
}

// 11. Compliance Trend (Last 5 Assessments progress over time)
$trend = [];
$res = $conn->query("SELECT a.created_at, a.compliance_percentage, c.company_name FROM assessments a JOIN companies c ON a.company_id = c.company_id ORDER BY a.created_at ASC LIMIT 8");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        $trend[] = [
            "label" => $row["company_name"] . " (" . date("d M", strtotime($row["created_at"])) . ")",
            "score" => (float)$row["compliance_percentage"]
        ];
    }
}
$stats["compliance_trend"] = $trend;

send_success("Dashboard stats retrieved.", $stats);
?>
