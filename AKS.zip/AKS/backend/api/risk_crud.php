<?php
// backend/api/risk_crud.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

// Enforce login and validate CSRF
start_secure_session();
if (isset($_SESSION['admin_id'])) {
    require_admin_login();
} else {
    require_user_login();
}

$method = $_SERVER['REQUEST_METHOD'];

switch ($method) {
    case 'GET':
        $company_id = $_GET['company_id'] ?? 0;
        
        if ($company_id > 0) {
            $stmt = $conn->prepare("
                SELECT r.*, c.company_name 
                FROM risk_register r 
                JOIN companies c ON r.company_id = c.company_id 
                WHERE r.company_id = ? 
                ORDER BY r.created_at DESC
            ");
            $stmt->bind_param("i", $company_id);
        } else {
            $stmt = $conn->prepare("
                SELECT r.*, c.company_name 
                FROM risk_register r 
                JOIN companies c ON r.company_id = c.company_id 
                ORDER BY r.created_at DESC
            ");
        }
        
        $stmt->execute();
        $result = $stmt->get_result();
        
        $risks = [];
        while ($row = $result->fetch_assoc()) {
            // Calculate score
            $row['risk_score'] = $row['impact'] * $row['likelihood'];
            $risks[] = $row;
        }
        
        send_success("Risks loaded successfully.", $risks);
        break;

    case 'POST':
        $input = json_decode(file_get_contents("php://input"), true);
        $company_id = (int)($input['company_id'] ?? 0);
        $risk_name = trim($input['risk_name'] ?? '');
        $impact = (int)($input['impact'] ?? 1);
        $likelihood = (int)($input['likelihood'] ?? 1);
        $mitigation = trim($input['mitigation'] ?? '');
        $status = trim($input['status'] ?? 'Open');

        if ($company_id <= 0 || empty($risk_name)) {
            send_error("Company ID and risk name are required.");
        }

        // Automatic risk score and severity calculation
        $score = $impact * $likelihood;
        $severity = 'Low';
        if ($score >= 20) $severity = 'Critical';
        elseif ($score >= 13) $severity = 'High';
        elseif ($score >= 6) $severity = 'Medium';

        $stmt = $conn->prepare("
            INSERT INTO risk_register (company_id, risk_name, severity, impact, likelihood, mitigation, status) 
            VALUES (?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("issiiis", $company_id, $risk_name, $severity, $impact, $likelihood, $mitigation, $status);
        
        if ($stmt->execute()) {
            log_audit_activity("Added new risk: " . $risk_name);
            send_success("Risk added successfully.", ["risk_id" => $stmt->insert_id], 201);
        } else {
            send_error("Failed to add risk.", 500);
        }
        break;

    case 'PUT':
        $input = json_decode(file_get_contents("php://input"), true);
        $risk_id = (int)($input['risk_id'] ?? 0);
        $risk_name = trim($input['risk_name'] ?? '');
        $impact = (int)($input['impact'] ?? 1);
        $likelihood = (int)($input['likelihood'] ?? 1);
        $mitigation = trim($input['mitigation'] ?? '');
        $status = trim($input['status'] ?? 'Open');

        if ($risk_id <= 0 || empty($risk_name)) {
            send_error("Risk ID and risk name are required.");
        }

        // Automatic risk score and severity calculation
        $score = $impact * $likelihood;
        $severity = 'Low';
        if ($score >= 20) $severity = 'Critical';
        elseif ($score >= 13) $severity = 'High';
        elseif ($score >= 6) $severity = 'Medium';

        $stmt = $conn->prepare("
            UPDATE risk_register 
            SET risk_name = ?, severity = ?, impact = ?, likelihood = ?, mitigation = ?, status = ? 
            WHERE risk_id = ?
        ");
        $stmt->bind_param("ssiissi", $risk_name, $severity, $impact, $likelihood, $mitigation, $status, $risk_id);
        
        if ($stmt->execute()) {
            log_audit_activity("Updated risk: " . $risk_name);
            send_success("Risk updated successfully.");
        } else {
            send_error("Failed to update risk.", 500);
        }
        break;

    case 'DELETE':
        $input = json_decode(file_get_contents("php://input"), true);
        $risk_id = (int)($input['risk_id'] ?? 0);

        if ($risk_id <= 0) {
            send_error("Valid risk ID is required.");
        }

        $stmt = $conn->prepare("DELETE FROM risk_register WHERE risk_id = ?");
        $stmt->bind_param("i", $risk_id);
        
        if ($stmt->execute()) {
            log_audit_activity("Deleted risk ID: " . $risk_id);
            send_success("Risk deleted successfully.");
        } else {
            send_error("Failed to delete risk.", 500);
        }
        break;

    default:
        send_error("Unsupported request method.", 405);
        break;
}
?>
