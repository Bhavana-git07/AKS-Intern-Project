<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

// CSRF check
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $headers = getallheaders();
    $csrfToken = $headers['X-CSRF-Token'] ?? '';
    if (!validate_csrf_token($csrfToken)) {
        send_error("CSRF token verification failed.", 403);
    }

    $company_id = $_POST['company_id'] ?? null;
    $framework = isset($_POST['framework']) ? $_POST['framework'] : null;
    $control_code = isset($_POST['control_code']) ? $_POST['control_code'] : null;

    if (!$company_id || !isset($_FILES['document'])) {
        send_error("Missing required fields.");
    }

    $file = $_FILES['document'];
    
    // 1. Enforce size limit: 10MB max
    $maxSize = 10 * 1024 * 1024;
    if ($file['size'] > $maxSize) {
        send_error("File size exceeds 10MB limit.");
    }

    // 2. Validate extension
    $origName = $file['name'];
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $allowedExts = ['pdf', 'doc', 'docx', 'xls', 'xlsx', 'txt'];
    if (!in_array($ext, $allowedExts)) {
        send_error("Unsupported file extension. Only PDF, DOC/DOCX, XLS/XLSX, and TXT are permitted.");
    }

    // 3. Validate MIME-type
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $file['tmp_name']);
    finfo_close($finfo);

    $allowedMimes = [
        'application/pdf',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'text/plain'
    ];

    if (!in_array($mime, $allowedMimes)) {
        send_error("Unsupported file type (MIME mismatch).");
    }

    $folder = "../uploads/";

    // Ensure uploads directory exists
    if (!file_exists($folder)) {
        mkdir($folder, 0755, true);
    }

    // Generate secure filename using random string + sanitized base extension
    $safeName = time() . "_" . bin2hex(random_bytes(8)) . "." . $ext;
    $file_path = $folder . $safeName;

    if (move_uploaded_file($file['tmp_name'], $file_path)) {
        $stmt = $conn->prepare("
            INSERT INTO documents (company_id, file_name, file_path, framework, control_code) 
            VALUES (?, ?, ?, ?, ?)
        ");
        $stmt->bind_param("issss", $company_id, $safeName, $file_path, $framework, $control_code);
        if ($stmt->execute()) {
            $document_id = $stmt->insert_id;
            log_audit_activity("Uploaded evidence document: " . $origName);

            // Extract plain text natively
            require_once '../config/pdf_helper.php';
            $extracted_text = extract_document_text($file_path);

            if (!empty($extracted_text)) {
                $stmtContent = $conn->prepare("
                    INSERT INTO document_content (document_id, extracted_text) 
                    VALUES (?, ?)
                ");
                $stmtContent->bind_param("is", $document_id, $extracted_text);
                $stmtContent->execute();
            }

            echo json_encode([
                "success" => true,
                "message" => "File uploaded successfully."
            ]);
        } else {
            send_error("Database error saving document record.");
        }
    } else {
        send_error("Failed to move uploaded file.");
    }
} else {
    send_error("Invalid request method.", 405);
}
?>