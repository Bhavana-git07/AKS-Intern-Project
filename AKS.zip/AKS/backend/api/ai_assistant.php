<?php
// backend/api/ai_assistant.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

// Enforce login
start_secure_session();
if (isset($_SESSION['admin_id'])) {
    require_admin_login();
} else {
    require_user_login();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$message = trim($input['message'] ?? '');
$company_id = (int)($input['company_id'] ?? 0);

if (empty($message)) {
    send_error("Message cannot be empty.");
}

// 1. Context Retrieval: Search matching document content
$context = "";
if ($company_id > 0) {
    $stmt = $conn->prepare("
        SELECT dc.extracted_text, d.file_name, d.control_code 
        FROM document_content dc 
        JOIN documents d ON dc.document_id = d.document_id 
        WHERE d.company_id = ?
        ORDER BY dc.created_at DESC LIMIT 3
    ");
    $stmt->bind_param("i", $company_id);
} else {
    $stmt = $conn->prepare("
        SELECT dc.extracted_text, d.file_name, d.control_code 
        FROM document_content dc 
        JOIN documents d ON dc.document_id = d.document_id 
        ORDER BY dc.created_at DESC LIMIT 3
    ");
}

$stmt->execute();
$res = $stmt->get_result();

$docsFound = [];
while ($row = $res->fetch_assoc()) {
    $docsFound[] = "[File: " . $row['file_name'] . " (Control: " . $row['control_code'] . ")] " . substr($row['extracted_text'], 0, 500);
}

if (!empty($docsFound)) {
    $context = "Relevant evidence documents found:\n" . implode("\n\n", $docsFound);
} else {
    $context = "No uploaded evidence documents found for context.";
}

// 2. Gemini API integration
$apiKey = getenv('GEMINI_API_KEY') ?: ''; // Read from env if present

$ai_response = "";
$usingRealAi = false;

if (!empty($apiKey)) {
    $url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=" . $apiKey;
    
    $prompt = "You are a senior Cybersecurity Compliance Auditor and AI Assistant. Help the user evaluate their compliance posture.\n\n";
    $prompt .= "CONTEXT FROM UPLOADED DOCUMENTS:\n" . $context . "\n\n";
    $prompt .= "USER QUERY: " . $message . "\n\n";
    $prompt .= "Provide clear, professional guidance pointing to specific frameworks (PayNet, BNM RMiT, MAS TRM) when relevant.";

    $data = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ]
    ];

    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    
    // Disable SSL verification issues on local XAMPP setups if curl certificates are not configured
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($httpCode === 200) {
        $json = json_decode($response, true);
        $ai_response = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
        if (!empty($ai_response)) {
            $usingRealAi = true;
        }
    }
}

// 3. Fallback Intelligent Rule-Engine (Zero-Config / Offline mode)
if (!$usingRealAi) {
    $msgLower = strtolower($message);
    $ai_response = "### 🛡️ Compliance Assistant Recommendation\n\n";
    
    if (strpos($msgLower, 'mfa') !== false || strpos($msgLower, 'otp') !== false || strpos($msgLower, 'multi-factor') !== false) {
        $ai_response .= "Based on your query regarding Multi-Factor Authentication (MFA):\n\n" .
                        "- **BNM RMiT (Malaysia):** Appears under control requirement *Access Control (Section 10.4)*. Requires strong authentication like hardware tokens or push OTP for administrative sessions.\n" .
                        "- **PayNet TPA:** Requires MFA for all third-party processor access pathways.\n\n" .
                        "**Evidence Evaluation:** We scanned your uploaded logs and verify that the platform successfully implements a database-backed 6-digit OTP engine on admin sign-in.";
    } elseif (strpos($msgLower, 'firewall') !== false || strpos($msgLower, 'network') !== false || strpos($msgLower, 'port') !== false) {
        $ai_response .= "Based on your query regarding Network Security / Firewalls:\n\n" .
                        "- **MAS TRM (Singapore):** Section 11 requires active network separation and firewall configuration logging.\n" .
                        "- **NACSA NC-II:** Enforces strict boundary protection and intrusion detection/prevention systems.\n\n" .
                        "**Remediation Suggestion:** Upload firewall configuration output as a `.txt` file, map it to the network controls, and execute the alignment mapper.";
    } elseif (strpos($msgLower, 'gap') !== false || strpos($msgLower, 'overlap') !== false) {
        $ai_response .= "Based on your query regarding Cross-Framework Overlap and Gaps:\n\n" .
                        "The system's built-in **Taxonomy Overlap Mapper** identifies mutual controls across PayNet and MAS TRM. For instance, Access Auditing overlaps by 85%. Matching a control in one automatically flags related requirements.";
    } else {
        $ai_response .= "Thank you for asking. Here is a general assessment based on your active company context:\n\n" .
                        "1. **Active Frameworks:** PayNet TPA, BNM RMiT, and MAS TRM.\n" .
                        "2. **Evidence Documents:** Currently " . (count($docsFound) > 0 ? "indexed and searchable" : "no documents uploaded yet") . ".\n\n" .
                        "Please ask me specifically about MFA, Firewall Rules, Gap Analysis, or specific framework controls for detailed mapping support.";
    }
    
    $ai_response .= "\n\n*(Note: Running in offline/fallback mode. Configure `GEMINI_API_KEY` for live AI generation)*";
}

// Log AI assistant request in activity logs
log_audit_activity("Queried compliance AI assistant");

echo json_encode([
    "success" => true,
    "response" => $ai_response,
    "real_ai" => $usingRealAi
]);
?>
