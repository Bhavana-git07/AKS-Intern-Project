<?php
// api/company_add.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$company_name = trim($input['company_name'] ?? '');
$registration_number = trim($input['registration_number'] ?? '');
$industry = trim($input['industry'] ?? '');
$address = trim($input['address'] ?? '');
$contact_email = trim($input['contact_email'] ?? '');
$contact_phone = trim($input['contact_phone'] ?? '');

if (empty($company_name)) {
    send_error("Company name is required.");
}

if (!empty($contact_email) && !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) {
    send_error("Invalid contact email.");
}

$stmt = $conn->prepare("INSERT INTO companies (company_name, registration_number, industry, address, contact_email, contact_phone) VALUES (?, ?, ?, ?, ?, ?)");
$stmt->bind_param("ssssss", $company_name, $registration_number, $industry, $address, $contact_email, $contact_phone);

if ($stmt->execute()) {
    log_audit_activity("Created company: " . $company_name);
    send_success("Company added successfully.", ["company_id" => $stmt->insert_id], 201);
} else {
    send_error("Failed to add company: " . $stmt->error, 500);
}
