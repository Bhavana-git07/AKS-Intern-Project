<?php
// backend/api/csrf_token.php
require_once '../config/response.php';
require_once '../config/auth.php';

start_secure_session();
send_success(['csrf_token' => generate_csrf_token()]);
?>
