<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

$assessment_id = $_GET['assessment_id'] ?? 0;

$stmt = $conn->prepare("SELECT compliance_percentage FROM assessments WHERE assessment_id = ?");
$stmt->bind_param("i", $assessment_id);
$stmt->execute();
$result = $stmt->get_result();

echo json_encode([
    "success" => true,
    "data" => $result->fetch_assoc()
]);
?>