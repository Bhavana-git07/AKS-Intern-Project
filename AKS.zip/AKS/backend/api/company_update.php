<?php
// api/company_update.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'PUT') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$company_id = (int)($input['company_id'] ?? 0);
$company_name = trim($input['company_name'] ?? '');
$registration_number = trim($input['registration_number'] ?? '');
$industry = trim($input['industry'] ?? '');
$address = trim($input['address'] ?? '');
$contact_email = trim($input['contact_email'] ?? '');
$contact_phone = trim($input['contact_phone'] ?? '');

if ($company_id <= 0 || empty($company_name)) {
    send_error("Company ID and name are required.");
}

$stmt = $conn->prepare("UPDATE companies SET company_name = ?, registration_number = ?, industry = ?, address = ?, contact_email = ?, contact_phone = ? WHERE company_id = ?");
$stmt->bind_param("ssssssi", $company_name, $registration_number, $industry, $address, $contact_email, $contact_phone, $company_id);

if ($stmt->execute()) {
    log_audit_activity("Updated company: " . $company_name);
    send_success("Company updated successfully.");
} else {
    send_error("Failed to update company: " . $stmt->error, 500);
}
