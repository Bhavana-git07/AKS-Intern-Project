<?php
// api/user_login.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

validate_request_csrf();

$input = json_decode(file_get_contents("php://input"), true);
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if (empty($email) || empty($password)) {
    send_error("Email and password are required.");
}

$stmt = $conn->prepare("SELECT user_id, company_id, full_name, email, password, role, first_login FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    send_error("Invalid email or password.", 401);
}

$user = $result->fetch_assoc();

if (!password_verify($password, $user['password'])) {
    send_error("Invalid email or password.", 401);
}

start_secure_session();
$_SESSION['temp_login'] = [
    "id" => $user['user_id'],
    "type" => "user",
    "company_id" => $user['company_id'],
    "role" => $user['role'],
    "name" => $user['full_name'],
    "email" => $user['email'],
    "first_login" => (bool)$user['first_login']
];

$otp = create_mfa_otp($user['user_id'], 'user');

send_success("MFA verification required.", [
    "mfa_required" => true,
    "email" => $user['email']
]);
