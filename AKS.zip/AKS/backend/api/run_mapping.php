<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

$assessment_id = $_GET['assessment_id'] ?? 0;

$stmt1 = $conn->prepare("SELECT * FROM assessments WHERE assessment_id = ?");
$stmt1->bind_param("i", $assessment_id);
$stmt1->execute();
$assessment = $stmt1->get_result()->fetch_assoc();

if (!$assessment) {
    send_error("Assessment not found.");
}

$current = $assessment['current_framework_id'];
$target = $assessment['target_framework_id'];

$stmt2 = $conn->prepare("
    SELECT c.control_id, cm.master_control_id 
    FROM controls c 
    JOIN control_mappings cm ON c.control_id = cm.control_id 
    WHERE c.framework_id = ?
");
$stmt2->bind_param("i", $target);
$stmt2->execute();
$target_controls = $stmt2->get_result();

$total = 0;
$matched = 0;

$stmtInsert = $conn->prepare("
    INSERT INTO assessment_controls (assessment_id, control_id, status) 
    VALUES (?, ?, ?)
");

while ($row = $target_controls->fetch_assoc()) {
    $total++;
    $master = $row['master_control_id'];
    $control = $row['control_id'];

    $stmtCheck = $conn->prepare("
        SELECT c.control_id 
        FROM controls c 
        JOIN control_mappings cm ON c.control_id = cm.control_id 
        WHERE c.framework_id = ? AND cm.master_control_id = ?
    ");
    $stmtCheck->bind_param("ii", $current, $master);
    $stmtCheck->execute();
    $exists = $stmtCheck->get_result();

    $status = "Missing";
    if ($exists->num_rows > 0) {
        $status = "Matched";
        $matched++;
    }

    $stmtInsert->bind_param("iis", $assessment_id, $control, $status);
    $stmtInsert->execute();
}

$percentage = 0;
if ($total > 0) {
    $percentage = ($matched / $total) * 100;
}

$stmtUpdate = $conn->prepare("
    UPDATE assessments 
    SET compliance_percentage = ? 
    WHERE assessment_id = ?
");
$stmtUpdate->bind_param("di", $percentage, $assessment_id);
$stmtUpdate->execute();

echo json_encode([
    "success" => true,
    "matched_controls" => $matched,
    "missing_controls" => $total - $matched,
    "compliance_percentage" => $percentage
]);
?>