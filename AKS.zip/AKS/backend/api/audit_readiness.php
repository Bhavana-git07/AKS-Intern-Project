<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

// CSRF check
if (isset($_SERVER['REQUEST_METHOD']) && ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'PUT' || $_SERVER['REQUEST_METHOD'] === 'DELETE')) {
    $headers = getallheaders();
    $csrfToken = $headers['X-CSRF-Token'] ?? '';
    if (!validate_csrf_token($csrfToken)) {
        send_error("CSRF token verification failed.", 403);
    }
}

$assessment_id = $_GET['assessment_id'] ?? 0;

$stmt = $conn->prepare("SELECT compliance_percentage FROM assessments WHERE assessment_id = ?");
$stmt->bind_param("i", $assessment_id);
$stmt->execute();
$result = $stmt->get_result();
$data = $result->fetch_assoc();

if (!$data) {
    send_error("Assessment not found.");
}

$percentage = $data['compliance_percentage'];
$status = '';

if ($percentage >= 80) {
    $status = 'Ready';
} elseif ($percentage >= 50) {
    $status = 'Partially Ready';
} else {
    $status = 'Not Ready';
}

echo json_encode([
    "success" => true,
    "percentage" => $percentage,
    "status" => $status
]);
?>