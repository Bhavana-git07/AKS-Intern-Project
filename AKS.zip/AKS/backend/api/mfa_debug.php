<?php
// backend/api/mfa_debug.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

start_secure_session();

if (!isset($_SESSION['temp_login'])) {
    send_error("No pending login session found.", 400);
}

$temp = $_SESSION['temp_login'];
$otp = get_last_otp_debug($temp['id'], $temp['type']);

if ($otp) {
    send_success("MFA Debug code fetched successfully.", ["otp" => $otp]);
} else {
    send_error("No active OTP code found or it has expired.");
}
?>
