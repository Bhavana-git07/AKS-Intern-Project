<?php
// api/logout.php
require_once '../config/response.php';
require_once '../config/auth.php';

start_secure_session();
log_audit_activity("User logged out");
$_SESSION = [];
session_destroy();

send_success("Logged out successfully.");
