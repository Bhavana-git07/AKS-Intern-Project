<?php
// api/login.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

validate_request_csrf();

$input = json_decode(file_get_contents("php://input"), true);
$email = trim($input['email'] ?? '');
$password = $input['password'] ?? '';

if (empty($email) || empty($password)) {
    send_error("Email and password are required.");
}

// Prepared statement — NEVER concatenate user input into SQL.
$stmt = $conn->prepare("SELECT admin_id, name, email, password FROM admins WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    send_error("Invalid email or password.", 401);
}

$admin = $result->fetch_assoc();

if (!password_verify($password, $admin['password'])) {
    send_error("Invalid email or password.", 401);
}

start_secure_session();
$_SESSION['temp_login'] = [
    "id" => $admin['admin_id'],
    "type" => "admin",
    "name" => $admin['name'],
    "email" => $admin['email']
];

$otp = create_mfa_otp($admin['admin_id'], 'admin');

send_success("MFA verification required.", [
    "mfa_required" => true,
    "email" => $admin['email']
]);
