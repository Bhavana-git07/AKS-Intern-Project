<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

// CSRF Check
if (isset($_SERVER['REQUEST_METHOD']) && ($_SERVER['REQUEST_METHOD'] === 'POST' || $_SERVER['REQUEST_METHOD'] === 'PUT' || $_SERVER['REQUEST_METHOD'] === 'DELETE')) {
    $headers = getallheaders();
    $csrfToken = $headers['X-CSRF-Token'] ?? '';
    if (!validate_csrf_token($csrfToken)) {
        send_error("CSRF token verification failed.", 403);
    }
}

$data = json_decode(file_get_contents("php://input"), true);
$checklist_id = $data['checklist_id'] ?? 0;
$is_completed = $data['is_completed'] ?? 0;

/* Update checklist item */
$stmt = $conn->prepare("UPDATE audit_checklist SET is_completed = ? WHERE checklist_id = ?");
$stmt->bind_param("ii", $is_completed, $checklist_id);
$stmt->execute();

/* Get audit_id */
$stmtGetAudit = $conn->prepare("SELECT audit_id FROM audit_checklist WHERE checklist_id = ?");
$stmtGetAudit->bind_param("i", $checklist_id);
$stmtGetAudit->execute();
$row = $stmtGetAudit->get_result()->fetch_assoc();

if (!$row) {
    send_error("Checklist item not found.");
}

$audit_id = $row['audit_id'];

/* Total items */
$stmtTotal = $conn->prepare("SELECT COUNT(*) AS total FROM audit_checklist WHERE audit_id = ?");
$stmtTotal->bind_param("i", $audit_id);
$stmtTotal->execute();
$total = $stmtTotal->get_result()->fetch_assoc()['total'];

/* Completed items */
$stmtCompleted = $conn->prepare("SELECT COUNT(*) AS completed FROM audit_checklist WHERE audit_id = ? AND is_completed = 1");
$stmtCompleted->bind_param("i", $audit_id);
$stmtCompleted->execute();
$completed = $stmtCompleted->get_result()->fetch_assoc()['completed'];

$progress = 0;
if ($total > 0) {
    $progress = round(($completed / $total) * 100);
}

/* Update progress */
$stmt2 = $conn->prepare("UPDATE audits SET progress = ? WHERE audit_id = ?");
$stmt2->bind_param("ii", $progress, $audit_id);
$stmt2->execute();

/* If completed */
if ($progress == 100) {
    $stmtStatus = $conn->prepare("UPDATE audits SET status = 'Completed' WHERE audit_id = ?");
    $stmtStatus->bind_param("i", $audit_id);
    $stmtStatus->execute();
} else {
    $stmtStatus = $conn->prepare("UPDATE audits SET status = 'In Progress' WHERE audit_id = ?");
    $stmtStatus->bind_param("i", $audit_id);
    $stmtStatus->execute();
}

echo json_encode([
    "success" => true,
    "progress" => $progress
]);
?>