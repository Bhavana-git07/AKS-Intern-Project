<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

$assessment_id = $_GET['assessment_id'] ?? 0;

$stmt1 = $conn->prepare("SELECT assessment_id, compliance_percentage FROM assessments WHERE assessment_id = ?");
$stmt1->bind_param("i", $assessment_id);
$stmt1->execute();
$assessment = $stmt1->get_result()->fetch_assoc();

if (!$assessment) {
    send_error("Assessment not found.");
}

$stmt2 = $conn->prepare("SELECT COUNT(*) AS total FROM assessment_controls WHERE assessment_id = ? AND status = 'Matched'");
$stmt2->bind_param("i", $assessment_id);
$stmt2->execute();
$matched = $stmt2->get_result()->fetch_assoc();

$stmt3 = $conn->prepare("SELECT COUNT(*) AS total FROM assessment_controls WHERE assessment_id = ? AND status = 'Missing'");
$stmt3->bind_param("i", $assessment_id);
$stmt3->execute();
$missing = $stmt3->get_result()->fetch_assoc();

echo json_encode([
    "success" => true,
    "assessment_id" => $assessment_id,
    "matched_controls" => $matched['total'] ?? 0,
    "missing_controls" => $missing['total'] ?? 0,
    "compliance_percentage" => $assessment['compliance_percentage'] ?? 0
]);
?>