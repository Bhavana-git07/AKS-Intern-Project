<?php
require('../fpdf/fpdf.php');
include('../config/database.php');
require_once '../config/response.php';
require_once '../config/auth.php';

$assessment_id = $_GET['assessment_id'] ?? 0;

// Prevent SQL injection using Prepared Statements
$stmt1 = $conn->prepare("
    SELECT a.*, c.company_name 
    FROM assessments a 
    JOIN companies c ON a.company_id = c.company_id 
    WHERE a.assessment_id = ?
");
$stmt1->bind_param("i", $assessment_id);
$stmt1->execute();
$assessment = $stmt1->get_result()->fetch_assoc();

if (!$assessment) {
    die("Assessment not found.");
}

$percentage = round($assessment['compliance_percentage'] ?? 0, 1);

$stmt2 = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM assessment_controls 
    WHERE assessment_id = ? AND status = 'Matched'
");
$stmt2->bind_param("i", $assessment_id);
$stmt2->execute();
$matched = $stmt2->get_result()->fetch_assoc()['total'] ?? 0;

$stmt3 = $conn->prepare("
    SELECT COUNT(*) AS total 
    FROM assessment_controls 
    WHERE assessment_id = ? AND status = 'Missing'
");
$stmt3->bind_param("i", $assessment_id);
$stmt3->execute();
$missing = $stmt3->get_result()->fetch_assoc()['total'] ?? 0;

/* ================= RISK ENGINE ================= */
if ($percentage >= 85) {
    $risk = "LOW RISK";
    $riskColor = [46, 204, 113]; // Green
    $riskBadgeText = "Low security posture risk identified.";
} elseif ($percentage >= 60) {
    $risk = "MEDIUM RISK";
    $riskColor = [241, 196, 15]; // Orange-yellow
    $riskBadgeText = "Moderate security vulnerabilities exist. Patching needed.";
} else {
    $risk = "HIGH RISK";
    $riskColor = [231, 76, 60]; // Red
    $riskBadgeText = "Critical security exposure detected. Remediate gaps immediately.";
}

/* ================= PDF CLASS ================= */
class PDF extends FPDF {
    function Header() {
        // Dark premium header bar
        $this->SetFillColor(24, 28, 36);
        $this->Rect(0, 0, 210, 24, 'F');

        $this->SetFont('Arial', 'B', 14);
        $this->SetTextColor(61, 214, 172); // Accent green
        $this->SetY(5);
        $this->Cell(0, 6, 'ENTERPRISE COMPLIANCE AUDIT REPORT', 0, 1, 'C');

        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(160, 174, 192); // Muted secondary
        $this->Cell(0, 4, 'Automated Regulatory Alignment & Risk Assessment System', 0, 1, 'C');
        
        $this->Ln(10);
        $this->SetTextColor(0, 0, 0);
    }

    function Footer() {
        $this->SetY(-15);
        $this->SetFont('Arial', 'I', 8);
        $this->SetTextColor(120, 120, 120);
        $this->Cell(0, 10, 'Confidential Compliance Ledger | Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

/* ================= INIT ================= */
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();

/* ================= META INFO ================= */
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Company Scope:', 0, 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $assessment['company_name'], 0, 0);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(35, 6, 'Date Generated:', 0, 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(35, 6, date('d M Y H:i'), 0, 1);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(40, 6, 'Assessment ID:', 0, 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(80, 6, $assessment_id, 0, 0);

$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(35, 6, 'Status:', 0, 0);
$pdf->SetFont('Arial', '', 10);
$pdf->Cell(35, 6, 'Audit Verified', 0, 1);

$pdf->Ln(5);
$pdf->Line(10, $pdf->GetY(), 200, $pdf->GetY());
$pdf->Ln(5);

/* ================= EXECUTIVE SUMMARY ================= */
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'EXECUTIVE AUDIT SUMMARY', 0, 1);
$pdf->SetFont('Arial', '', 10);

$summary = "This compliance audit report evaluates " . $assessment['company_name'] . " against standard mapping criteria. Based on the mapping analysis, the organization matches " . $matched . " controls, leaving " . $missing . " gaps open. The current compliance posture is rated as " . $risk . ".";
$pdf->MultiCell(0, 5, $summary);
$pdf->Ln(5);

/* ================= KPI DASHBOARD ================= */
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(248, 249, 250);
$pdf->SetTextColor(74, 85, 104);

$currentY = $pdf->GetY();
// Render 3 KPI blocks
$pdf->Rect(10, $currentY, 60, 18, 'F');
$pdf->SetXY(10, $currentY + 2);
$pdf->Cell(60, 4, 'COMPLIANCE', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(45, 55, 72);
$pdf->Cell(60, 8, $percentage . '%', 0, 0, 'C');

$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(74, 85, 104);
$pdf->Rect(75, $currentY, 60, 18, 'F');
$pdf->SetXY(75, $currentY + 2);
$pdf->Cell(60, 4, 'MATCHED CONTROLS', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(46, 204, 113);
$pdf->Cell(60, 8, $matched, 0, 0, 'C');

$pdf->SetFont('Arial', 'B', 9);
$pdf->SetTextColor(74, 85, 104);
$pdf->Rect(140, $currentY, 60, 18, 'F');
$pdf->SetXY(140, $currentY + 2);
$pdf->Cell(60, 4, 'MISSING GAPS', 0, 1, 'C');
$pdf->SetFont('Arial', 'B', 12);
$pdf->SetTextColor(231, 76, 60);
$pdf->Cell(60, 8, $missing, 0, 1, 'C');

$pdf->SetXY(10, $currentY + 22);
$pdf->SetTextColor(0, 0, 0);

/* ================= RISK STATEMENT ================= */
$pdf->SetFont('Arial', 'B', 10);
$pdf->SetFillColor($riskColor[0], $riskColor[1], $riskColor[2]);
$pdf->SetTextColor(255, 255, 255);
$pdf->Cell(190, 8, "POSTURE EVALUATION: " . $risk . " - " . $riskBadgeText, 0, 1, 'C', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->Ln(6);

/* ================= GAP ANALYSIS TABLE ================= */
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(0, 8, 'DETAILED GAPS & COMPLIANCE MATRIX', 0, 1);
$pdf->Ln(2);

/* TABLE HEADER */
$pdf->SetFont('Arial', 'B', 9);
$pdf->SetFillColor(240, 244, 248);
$pdf->SetTextColor(45, 55, 72);

$pdf->Cell(95, 8, 'Control Requirement Name', 1, 0, 'L', true);
$pdf->Cell(40, 8, 'Requirement Code', 1, 0, 'C', true);
$pdf->Cell(55, 8, 'Status Alignment', 1, 1, 'C', true);

$pdf->SetTextColor(0, 0, 0);
$pdf->SetFont('Arial', '', 9);

$stmt4 = $conn->prepare("
    SELECT c.control_name, c.control_code, ac.status 
    FROM assessment_controls ac 
    JOIN controls c ON ac.control_id = c.control_id 
    WHERE ac.assessment_id = ?
");
$stmt4->bind_param("i", $assessment_id);
$stmt4->execute();
$controls = $stmt4->get_result();

while ($row = $controls->fetch_assoc()) {
    // Auto page break check
    if ($pdf->GetY() > 260) {
        $pdf->AddPage();
        
        // Redraw table headers on new page
        $pdf->SetFont('Arial', 'B', 9);
        $pdf->SetFillColor(240, 244, 248);
        $pdf->SetTextColor(45, 55, 72);
        $pdf->Cell(95, 8, 'Control Requirement Name', 1, 0, 'L', true);
        $pdf->Cell(40, 8, 'Requirement Code', 1, 0, 'C', true);
        $pdf->Cell(55, 8, 'Status Alignment', 1, 1, 'C', true);
        $pdf->SetTextColor(0, 0, 0);
        $pdf->SetFont('Arial', '', 9);
    }

    // Wrap long control names using multi-row heights if needed
    $name = $row['control_name'];
    if (strlen($name) > 55) {
        $name = substr($name, 0, 52) . "...";
    }

    $pdf->Cell(95, 7, $name, 1, 0, 'L');
    $pdf->Cell(40, 7, $row['control_code'], 1, 0, 'C');

    if ($row['status'] === 'Matched') {
        $pdf->SetTextColor(46, 204, 113);
    } else {
        $pdf->SetTextColor(231, 76, 60);
    }

    $pdf->Cell(55, 7, $row['status'], 1, 1, 'C');
    $pdf->SetTextColor(0, 0, 0);
}

/* ================= FOOTER / SIGN OFF ================= */
$pdf->Ln(6);
$pdf->SetFont('Arial', 'I', 8);
$pdf->SetTextColor(113, 128, 150);
$pdf->MultiCell(0, 4, "Disclaimer: This compliance evaluation report was programmatically generated by checking evidence bindings. Final sign-off is required by a certified auditor.");

// Log PDF generation activity
log_audit_activity("Generated compliance report for assessment ID: " . $assessment_id);

$pdf->Output();
?>