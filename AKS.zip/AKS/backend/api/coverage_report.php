<?php
include '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

$assessment_id = $_GET['assessment_id'] ?? 0;

$stmt1 = $conn->prepare("SELECT * FROM assessments WHERE assessment_id = ?");
$stmt1->bind_param("i", $assessment_id);
$stmt1->execute();
$assessment = $stmt1->get_result()->fetch_assoc();

if (!$assessment) {
    send_error("Assessment not found.");
}

$framework = $assessment['target_framework_id'];

$stmt2 = $conn->prepare("SELECT COUNT(*) AS total FROM controls WHERE framework_id = ?");
$stmt2->bind_param("i", $framework);
$stmt2->execute();
$total = $stmt2->get_result()->fetch_assoc();

$stmt3 = $conn->prepare("SELECT COUNT(*) AS total FROM assessment_controls WHERE assessment_id = ? AND status = 'Matched'");
$stmt3->bind_param("i", $assessment_id);
$stmt3->execute();
$covered = $stmt3->get_result()->fetch_assoc();

$percentage = 0;
if ($total['total'] > 0) {
    $percentage = ($covered['total'] / $total['total']) * 100;
}

echo json_encode([
    "success" => true,
    "total_controls" => $total['total'] ?? 0,
    "covered_controls" => $covered['total'] ?? 0,
    "coverage_percentage" => $percentage
]);
?>