<?php
// backend/config/pdf_helper.php
// Self-contained PDF and text parser.

function extract_document_text($file_path) {
    if (!file_exists($file_path)) {
        return "";
    }
    
    $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
    
    if ($ext === 'txt') {
        return file_get_contents($file_path);
    }
    
    if ($ext === 'pdf') {
        return parse_pdf_text($file_path);
    }
    
    // For other document types (doc, docx, xls, xlsx), return file metadata as fallback
    return "Document: " . basename($file_path);
}

function parse_pdf_text($filename) {
    $content = file_get_contents($filename);
    if (empty($content)) {
        return "";
    }
    
    $texts = [];
    
    // 1. Locate all streams
    preg_match_all("/stream(.*?)endstream/is", $content, $matches);
    
    foreach ($matches[1] as $stream) {
        $stream = trim($stream);
        
        // Decompress FlateDecode stream if possible
        $data = @gzuncompress($stream);
        if ($data === false) {
            $data = $stream; // Fallback to raw stream
        }
        
        // 2. Parse text operator: (text) Tj
        preg_match_all("/\((.*?)\)\s*T[j*]/is", $data, $textMatches);
        if (!empty($textMatches[1])) {
            foreach ($textMatches[1] as $txt) {
                $texts[] = clean_pdf_string($txt);
            }
        }
        
        // 3. Parse text operator: [(text1) 123 (text2)] TJ
        preg_match_all("/\[(.*?)\]\s*TJ/is", $data, $bracketMatches);
        if (!empty($bracketMatches[1])) {
            foreach ($bracketMatches[1] as $bracketContent) {
                preg_match_all("/\((.*?)\)/is", $bracketContent, $subMatches);
                if (!empty($subMatches[1])) {
                    foreach ($subMatches[1] as $txt) {
                        $texts[] = clean_pdf_string($txt);
                    }
                }
            }
        }
    }
    
    // Fallback regex if no streams yielded text
    if (empty($texts)) {
        preg_match_all("/\((.*?)\)/is", $content, $fallback);
        if (!empty($fallback[1])) {
            foreach ($fallback[1] as $txt) {
                if (strlen($txt) > 3 && preg_match('/^[a-zA-Z0-9\s\.\,\-\_\(\)]+$/', $txt)) {
                    $texts[] = clean_pdf_string($txt);
                }
            }
        }
    }
    
    return implode(" ", $texts);
}

function clean_pdf_string($str) {
    // Unescape parenthesis
    $str = str_replace(['\\(', '\\)', '\\\\'], ['(', ')', '\\'], $str);
    // Remove binary/non-ASCII characters
    return preg_replace('/[^\x20-\x7E\s]/', '', $str);
}
?>
