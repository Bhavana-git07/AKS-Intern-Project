<?php
// config/auth.php
// Shared auth helpers. Require this in any controller that needs
// session checks or password rules, instead of rewriting the logic.

function start_secure_session() {
    if (session_status() === PHP_SESSION_NONE) {
        $cookieParams = [
            'lifetime' => 0,
            'path' => '/',
            'domain' => '',
            'secure' => isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on',
            'httponly' => true,
            'samesite' => 'Strict'
        ];
        session_set_cookie_params($cookieParams);
        session_start();
    }
}

// CSRF Token Generation
function generate_csrf_token() {
    start_secure_session();
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

// CSRF Token Validation
function validate_csrf_token($token) {
    start_secure_session();
    if (!isset($_SESSION['csrf_token']) || empty($token)) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

// Validate CSRF token automatically for secure endpoints
function validate_request_csrf() {
    if (isset($_SERVER['REQUEST_METHOD']) && in_array($_SERVER['REQUEST_METHOD'], ['POST', 'PUT', 'DELETE'])) {
        $token = '';
        
        // 1. Check HTTP header X-CSRF-Token
        $headers = getallheaders();
        if (isset($headers['X-CSRF-Token'])) {
            $token = $headers['X-CSRF-Token'];
        } elseif (isset($headers['x-csrf-token'])) {
            $token = $headers['x-csrf-token'];
        }
        
        // 2. Fallback to check request input if JSON
        if (empty($token)) {
            $input = json_decode(file_get_contents("php://input"), true);
            if (isset($input['csrf_token'])) {
                $token = $input['csrf_token'];
            }
        }

        if (!validate_csrf_token($token)) {
            // Require config/response.php to send clean response
            if (function_exists('send_error')) {
                send_error("CSRF token verification failed.", 403);
            } else {
                http_response_code(403);
                die(json_encode(["success" => false, "message" => "CSRF token verification failed."]));
            }
        }
    }
}

// Use this at the top of ANY admin-only API endpoint
function require_admin_login() {
    start_secure_session();
    validate_request_csrf();
    if (!isset($_SESSION['admin_id'])) {
        if (function_exists('send_error')) {
            send_error("Unauthorized. Please log in.", 401);
        } else {
            http_response_code(401);
            die(json_encode(["success" => false, "message" => "Unauthorized. Please log in."]));
        }
    }
}

// Use this at the top of ANY user-only API endpoint
function require_user_login() {
    start_secure_session();
    validate_request_csrf();
    if (!isset($_SESSION['user_id'])) {
        if (function_exists('send_error')) {
            send_error("Unauthorized. Please log in.", 401);
        } else {
            http_response_code(401);
            die(json_encode(["success" => false, "message" => "Unauthorized. Please log in."]));
        }
    }
}

// Blocks access to everything except the change-password endpoint
// until the user has changed their temporary password.
function block_if_first_login() {
    start_secure_session();
    if (isset($_SESSION['first_login']) && $_SESSION['first_login'] == 1) {
        if (function_exists('send_error')) {
            send_error("Password change required before continuing.", 403);
        } else {
            http_response_code(403);
            die(json_encode(["success" => false, "message" => "Password change required before continuing."]));
        }
    }
}

// Centralized password complexity rule — reuse this everywhere
// a password is created or changed, so the rule never drifts.
function is_password_strong($password) {
    if (strlen($password) < 8) return false;
    if (!preg_match('/[A-Z]/', $password)) return false;
    if (!preg_match('/[a-z]/', $password)) return false;
    if (!preg_match('/[0-9]/', $password)) return false;
    if (!preg_match('/[\W_]/', $password)) return false; // special char
    return true;
}

// Generates a random temporary password that ALSO satisfies the
// complexity rule above
function generate_temp_password($length = 10) {
    $upper = "ABCDEFGHJKLMNPQRSTUVWXYZ";
    $lower = "abcdefghijkmnpqrstuvwxyz";
    $number = "23456789";
    $symbol = "!@#$%&*";

    $password = $upper[random_int(0, strlen($upper) - 1)]
              . $lower[random_int(0, strlen($lower) - 1)]
              . $number[random_int(0, strlen($number) - 1)]
              . $symbol[random_int(0, strlen($symbol) - 1)];

    $all = $upper . $lower . $number . $symbol;
    for ($i = strlen($password); $i < $length; $i++) {
        $password .= $all[random_int(0, strlen($all) - 1)];
    }

    return str_shuffle($password);
}

// Generate OTP and insert into database
function create_mfa_otp($user_id, $user_type) {
    global $conn;
    
    // Generate 6-digit code
    $otp = sprintf("%06d", random_int(100000, 999999));
    
    // Set expiration (10 minutes from now)
    $expires = date('Y-m-d H:i:s', time() + 600);
    
    // Insert into mfa_otp table
    $stmt = $conn->prepare("
        INSERT INTO mfa_otp (user_id, user_type, otp_code, expires_at, is_verified) 
        VALUES (?, ?, ?, ?, 0)
    ");
    $stmt->bind_param("isss", $user_id, $user_type, $otp, $expires);
    $stmt->execute();
    
    return $otp;
}

// Retrieve the last generated OTP for testing/debug view
function get_last_otp_debug($user_id, $user_type) {
    global $conn;
    $stmt = $conn->prepare("
        SELECT otp_code FROM mfa_otp 
        WHERE user_id = ? AND user_type = ? AND is_verified = 0 AND expires_at > NOW() 
        ORDER BY created_at DESC LIMIT 1
    ");
    $stmt->bind_param("is", $user_id, $user_type);
    $stmt->execute();
    $res = $stmt->get_result()->fetch_assoc();
    return $res['otp_code'] ?? null;
}

// Log security and audit activities in database
function log_audit_activity($action, $user_id = null, $user_type = null) {
    global $conn;
    
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    
    if ($user_id === null) {
        if (isset($_SESSION['admin_id'])) {
            $user_id = $_SESSION['admin_id'];
            $user_type = 'admin';
        } elseif (isset($_SESSION['user_id'])) {
            $user_id = $_SESSION['user_id'];
            $user_type = 'user';
        }
    }
    
    $ip = $_SERVER['REMOTE_ADDR'] ?? '127.0.0.1';
    
    $stmt = $conn->prepare("
        INSERT INTO audit_logs (user_id, user_type, action, ip_address) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->bind_param("isss", $user_id, $user_type, $action, $ip);
    $stmt->execute();
}
?>
