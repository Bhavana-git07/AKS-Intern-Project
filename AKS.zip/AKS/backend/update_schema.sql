-- update_schema.sql
-- Database update script. Run this in phpMyAdmin's SQL tab on database `aks`.

USE aks;

-- 1. Create frameworks table
CREATE TABLE IF NOT EXISTS frameworks (
    framework_id INT AUTO_INCREMENT PRIMARY KEY,
    framework_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed frameworks
INSERT INTO frameworks (framework_id, framework_name) VALUES
(1, 'PayNet TPA'),
(2, 'BNM RMiT'),
(3, 'MAS TRM'),
(4, 'NACSA NC-II')
ON DUPLICATE KEY UPDATE framework_id=framework_id;

-- 2. Create mfa_otp table
CREATE TABLE IF NOT EXISTS mfa_otp (
    otp_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    user_type ENUM('admin', 'user', 'auditor') NOT NULL,
    otp_code VARCHAR(10) NOT NULL,
    expires_at DATETIME NOT NULL,
    attempts INT DEFAULT 0,
    is_verified TINYINT DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. Create risk_register table
CREATE TABLE IF NOT EXISTS risk_register (
    risk_id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    risk_name VARCHAR(150) NOT NULL,
    severity ENUM('Low', 'Medium', 'High', 'Critical') NOT NULL,
    impact INT NOT NULL CHECK (impact BETWEEN 1 AND 5),
    likelihood INT NOT NULL CHECK (likelihood BETWEEN 1 AND 5),
    mitigation TEXT,
    status VARCHAR(50) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(company_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. Create document_content table for text extraction
CREATE TABLE IF NOT EXISTS document_content (
    content_id INT AUTO_INCREMENT PRIMARY KEY,
    document_id INT NOT NULL,
    extracted_text LONGTEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (document_id) REFERENCES documents(document_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
-- 5. Create audit_logs table
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT DEFAULT NULL,
    user_type VARCHAR(50) DEFAULT NULL,
    action VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
