/* ============================================
   COMPLIANCE AUDIT PLATFORM — GLOBAL JS
   ============================================ */

// ---- TOAST ----
function showToast(message, type = 'success') {
  const icons = {
    success: `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--clr-accent)"><path d="M20 6L9 17l-5-5"/></svg>`,
    error:   `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--clr-danger)"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`,
    info:    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="color:var(--clr-blue)"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`
  };
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container';
    document.body.appendChild(container);
  }
  const toast = document.createElement('div');
  toast.className = `toast toast--${type}`;
  toast.innerHTML = `${icons[type]}<span>${message}</span>`;
  container.appendChild(toast);
  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(20px)';
    toast.style.transition = '0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3200);
}

// ---- MODAL ----
function openModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.add('open'); document.body.style.overflow = 'hidden'; }
}
function closeModal(id) {
  const el = document.getElementById(id);
  if (el) { el.classList.remove('open'); document.body.style.overflow = ''; }
}
// Close on overlay click
document.addEventListener('click', e => {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
    document.body.style.overflow = '';
  }
});

// ---- SIDEBAR TOGGLE (mobile) ----
function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.querySelector('.sidebar-overlay');
  if (sidebar) sidebar.classList.toggle('open');
  if (overlay) overlay.classList.toggle('open');
}

// ---- FORM VALIDATION ----
function validateRequired(formEl) {
  let valid = true;
  formEl.querySelectorAll('[required]').forEach(input => {
    const err = input.closest('.form-group')?.querySelector('.form-error');
    if (!input.value.trim()) {
      input.classList.add('error');
      if (err) err.classList.add('show');
      valid = false;
    } else {
      input.classList.remove('error');
      if (err) err.classList.remove('show');
    }
  });
  return valid;
}

// ---- PASSWORD STRENGTH ----
function checkPasswordStrength(password) {
  let score = 0;
  if (password.length >= 8)  score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;
  return score; // 0-5
}

function renderPasswordStrength(score, barEl, labelEl) {
  const levels = [
    { label: 'Very Weak', color: '#F75F4F', w: '10%' },
    { label: 'Weak',      color: '#F7924F', w: '25%' },
    { label: 'Fair',      color: '#F7B24F', w: '50%' },
    { label: 'Good',      color: '#4F8EF7', w: '75%' },
    { label: 'Strong',    color: '#3DD6AC', w: '100%' }
  ];
  const lvl = levels[Math.min(score, 4)];
  if (barEl) { barEl.style.width = lvl.w; barEl.style.background = lvl.color; }
  if (labelEl) { labelEl.textContent = lvl.label; labelEl.style.color = lvl.color; }
}

// ---- ACTIVE NAV ----
function setActiveNav() {
  const path = window.location.pathname.split('/').pop();
  document.querySelectorAll('.nav-item').forEach(item => {
    const href = item.getAttribute('href') || '';
    item.classList.toggle('active', href === path || href.endsWith(path));
  });
}
document.addEventListener('DOMContentLoaded', setActiveNav);

// ---- TABLE SEARCH ----
function tableSearch(inputId, tableId) {
  const input = document.getElementById(inputId);
  const table = document.getElementById(tableId);
  if (!input || !table) return;
  input.addEventListener('input', () => {
    const q = input.value.toLowerCase();
    table.querySelectorAll('tbody tr').forEach(row => {
      row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
    });
  });
}

// ---- CONFIRM DELETE ----
function confirmDelete(message, onConfirm) {
  if (confirm(message || 'Are you sure? This action cannot be undone.')) {
    onConfirm();
  }
}
