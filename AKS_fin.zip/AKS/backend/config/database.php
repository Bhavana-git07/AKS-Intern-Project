<?php
// config/database.php
// Centralized DB connection. Never hardcode credentials in every file —
// require this file instead, everywhere you need $conn.

$DB_HOST = "localhost";
$DB_USER = "root";
$DB_PASS = "";
$DB_NAME = "aks";

$conn = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);

if ($conn->connect_error) {
    // Don't leak DB details to the client in production.
    http_response_code(500);
    die(json_encode([
        "success" => false,
        "message" => "Database connection failed"
    ]));
}

$conn->set_charset("utf8mb4");

// Auto-initialize login_attempts table for account lockout tracking
$conn->query("
CREATE TABLE IF NOT EXISTS login_attempts (
    attempt_id INT AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(100) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    attempt_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Auto-initialize risks table for Risk Register module
$conn->query("
CREATE TABLE IF NOT EXISTS risks (
    risk_id INT AUTO_INCREMENT PRIMARY KEY,
    company_id INT NOT NULL,
    risk_title VARCHAR(255) NOT NULL,
    risk_description TEXT,
    likelihood INT NOT NULL,
    impact INT NOT NULL,
    risk_score INT NOT NULL,
    mitigation_strategy TEXT,
    status VARCHAR(50) DEFAULT 'Open',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (company_id) REFERENCES companies(company_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
");

// Auto-initialize documents table alteration for RAG module
$col_check = $conn->query("SHOW COLUMNS FROM documents LIKE 'extracted_text'");
if ($col_check && $col_check->num_rows === 0) {
    $conn->query("ALTER TABLE documents ADD COLUMN extracted_text LONGTEXT DEFAULT NULL");
}

// Auto-initialize login_attempts index for faster lockout checks
$idx_check = $conn->query("SHOW INDEX FROM login_attempts WHERE Key_name = 'email'");
if ($idx_check && $idx_check->num_rows === 0) {
    $conn->query("ALTER TABLE login_attempts ADD INDEX (email)");
}
