<?php
// api/ai_chat.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';
require_once '../config/ai_config.php';

// 1. Verify CSRF Token
verify_csrf_token();

start_secure_session();

// Ensure user or admin is logged in
if (!isset($_SESSION['admin_id']) && !isset($_SESSION['user_id'])) {
    send_error("Unauthorized access. Please log in.", 401);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$user_message = trim($input['message'] ?? '');

if (empty($user_message)) {
    send_error("Message is required.");
}

// RAG: Dynamic backfill check for existing documents that do not have text extracted yet
$res_backfill = $conn->query("SELECT document_id, file_path FROM documents WHERE extracted_text IS NULL OR extracted_text = ''");
if ($res_backfill) {
    while ($row = $res_backfill->fetch_assoc()) {
        $doc_id = intval($row['document_id']);
        $file_path = __DIR__ . '/../' . str_replace('../', '', $row['file_path']);
        if (file_exists($file_path)) {
            $extracted_text = "";
            $ext = strtolower(pathinfo($file_path, PATHINFO_EXTENSION));
            if ($ext === 'txt') {
                $extracted_text = file_get_contents($file_path);
            } elseif ($ext === 'pdf') {
                $extracted_text = extract_pdf_text($file_path);
            } elseif ($ext === 'docx') {
                $extracted_text = extract_docx_text($file_path);
            } elseif ($ext === 'xlsx') {
                $extracted_text = extract_xlsx_text($file_path);
            }
            if (!empty($extracted_text)) {
                $stmt_up = $conn->prepare("UPDATE documents SET extracted_text = ? WHERE document_id = ?");
                $stmt_up->bind_param("si", $extracted_text, $doc_id);
                $stmt_up->execute();
            }
        }
    }
}

// RAG: Search relevant documents matching user message.
// Restrict search by company_id if user is a standard tenant user.
$user_company_id = isset($_SESSION['admin_id']) ? null : ($_SESSION['company_id'] ?? null);
$matched_docs = search_relevant_documents($user_message, $user_company_id);

// Format retrieved context
$retrieved_context = "";
if (!empty($matched_docs)) {
    $retrieved_context .= "\n\nRetrieved Context from Company Evidence Vault:\n";
    foreach ($matched_docs as $doc) {
        $retrieved_context .= "--- Document: " . $doc['file_name'] . " (Framework: " . $doc['framework'] . ", Control: " . $doc['control_code'] . ") ---\n";
        // Pass first 800 characters to keep payload sizes reasonable
        $retrieved_context .= substr($doc['extracted_text'], 0, 800) . "\n\n";
    }
}

// 2. Fetch current compliance statistics from database to feed context
$company_count = 0;
$doc_count = 0;
$active_audits = 0;
$completed_audits = 0;
$avg_progress = 0.0;
$risk_count = 0;
$avg_risk_score = 0.0;

// Get companies count
$res = $conn->query("SELECT COUNT(*) as count FROM companies");
if ($res) {
    $company_count = intval($res->fetch_assoc()['count']);
}

// Get documents count
$res = $conn->query("SELECT COUNT(*) as count FROM documents");
if ($res) {
    $doc_count = intval($res->fetch_assoc()['count']);
}

// Get audits progress
$res = $conn->query("SELECT status, COUNT(*) as count, AVG(progress) as avg_prog FROM audits GROUP BY status");
if ($res) {
    while ($row = $res->fetch_assoc()) {
        if ($row['status'] === 'Completed') {
            $completed_audits = intval($row['count']);
        } else {
            $active_audits += intval($row['count']);
        }
        $avg_progress += floatval($row['avg_prog']);
    }
    $total_audits = $active_audits + $completed_audits;
    if ($total_audits > 0) {
        $avg_progress = round($avg_progress / $total_audits, 1);
    }
}

// Get risks count and score
$res = $conn->query("SELECT COUNT(*) as count, AVG(risk_score) as avg_score FROM risks");
if ($res) {
    $row = $res->fetch_assoc();
    $risk_count = intval($row['count']);
    $avg_risk_score = $row['avg_score'] ? round(floatval($row['avg_score']), 1) : 0.0;
}

// 3. Build AI Context
$system_context = "You are the AKS Compliance Platform AI assistant. Here is the current system database state:\n";
$system_context .= "- Total registered companies: $company_count\n";
$system_context .= "- Total uploaded evidence documents: $doc_count\n";
$system_context .= "- Total active audits: $active_audits (completed: $completed_audits, average progress: $avg_progress%)\n";
$system_context .= "- Total registered risks: $risk_count (average risk score: $avg_risk_score/25)\n\n";
$system_context .= "Answer the user's questions utilizing this database state when appropriate. Respond professionally as a Lead Cybersecurity Compliance Auditor. Format responses in clean Markdown.";

// 4. Check query for Executive Summary request or similar keywords
$is_summary_req = false;
$q_lower = strtolower($user_message);
if (strpos($q_lower, 'executive summary') !== false || strpos($q_lower, 'generate summary') !== false || strpos($q_lower, 'compliance summary') !== false || strpos($q_lower, 'platform report') !== false) {
    $is_summary_req = true;
}

// 5. Query execution using Gemini or local analyzer fallback
if ($ai_api_key && $ai_provider === 'gemini') {
    // Call Google Gemini API with system context + RAG retrieved context + user message
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . urlencode($ai_api_key);
    
    $prompt = $system_context . $retrieved_context . "\n\nUser Request: " . $user_message;
    
    $payload = [
        "contents" => [
            [
                "parts" => [
                    ["text" => $prompt]
                ]
            ]
        ]
    ];
    
    $ch = curl_init($url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($payload));
    curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    if ($http_code === 200) {
        $res_data = json_decode($response, true);
        $ai_text = $res_data['candidates'][0]['content']['parts'][0]['text'] ?? '';
        if (!empty($ai_text)) {
            send_success("AI Response generated.", ["response" => $ai_text]);
        }
    }
}

// Fallback / Local Compliance Advisory Logic (If no key is configured, or API fails)
$ai_text = "";
if ($is_summary_req) {
    // Generate an executive summary
    $ai_text = "### 📊 Compliance Platform Executive Summary\n\n";
    $ai_text .= "**Date:** " . date('Y-m-d H:i:s') . "\n";
    $ai_text .= "**Auditor:** Lead AI Compliance Assistant\n\n";
    $ai_text .= "---\n\n";
    $ai_text .= "#### 🏢 1. Company Coverage & Scale\n";
    $ai_text .= "There are currently **{$company_count} registered companies** participating in the compliance framework audit program. ";
    if ($company_count > 0) {
        $ai_text .= "A active pipeline of compliance structures has been established for these entities.\n\n";
    } else {
        $ai_text .= "Attention: No companies are currently registered. Please initialize company profiles in the Management workspace.\n\n";
    }
    
    $ai_text .= "#### 📋 2. Audit & Readiness Progress\n";
    $ai_text .= "- **Total Active Audits:** {$active_audits}\n";
    $ai_text .= "- **Completed Audits:** {$completed_audits}\n";
    $ai_text .= "- **Average Framework Progress:** `{$avg_progress}%`\n\n";
    if ($avg_progress > 75) {
        $ai_text .= "🟢 *Assessment Health is strong.* The majority of target control parameters are validated and mapped.\n\n";
    } elseif ($avg_progress > 40) {
        $ai_text .= "🟡 *Assessment Health is moderate.* Several key audits are in progress. Enforce checklist updates and document collection.\n\n";
    } else {
        $ai_text .= "🔴 *Assessment Health is low.* Immediate attention is required to assign frameworks, gather evidence, and process mapping overlaps.\n\n";
    }
    
    $ai_text .= "#### 🛡️ 3. Risk Landscape & Posture\n";
    $ai_text .= "- **Registered Risks:** {$risk_count}\n";
    $ai_text .= "- **Average Risk Score:** `{$avg_risk_score} / 25`\n\n";
    if ($risk_count > 0) {
        if ($avg_risk_score >= 15) {
            $ai_text .= "❌ *High Risk Warning:* The average risk score falls in the critical range. Focus on mitigation strategies and control mapping immediately.\n\n";
        } else {
            $ai_text .= "✅ *Risk Profile is stable.* Keep updating mitigations and reviewing statuses.\n\n";
        }
    } else {
        $ai_text .= "ℹ️ No risks are logged in the Risk Register. Establish a threat catalog to support compliance mappings.\n\n";
    }
    
    $ai_text .= "#### 📂 4. Evidence Vault & Documentation\n";
    $ai_text .= "A total of **{$doc_count} evidence files** have been uploaded to the platform. ";
    if ($doc_count > 0) {
        $ai_text .= "These documents serve as audit proof mapping to frameworks like BNM RMiT, MAS TRM, and PayNet TPA. Ensure all pending items are reviewed.";
    } else {
        $ai_text .= "Warning: The evidence vault is empty. Upload compliance logs, policy documents, and configuration audit records.";
    }
} else {
    // General compliance advisory matching
    if (strpos($q_lower, 'rmit') !== false || strpos($q_lower, 'bnm') !== false) {
        $ai_text = "### 📋 BNM RMiT Compliance Advice\n\n";
        $ai_text .= "The Bank Negara Malaysia (BNM) Risk Management in Technology (RMiT) framework enforces strict standards for financial institutions.\n\n";
        $ai_text .= "#### Key Requirements:\n";
        $ai_text .= "1. **Technology Governance:** Board and Management oversight must ensure robust risk boundaries.\n";
        $ai_text .= "2. **Technology Risk Management:** Structured processes to identify, assess, and mitigate infrastructure exposures.\n";
        $ai_text .= "3. **Cyber Security Operations:** Setting up a 24/7 Security Operations Center (SOC) and incident response controls.\n\n";
        $ai_text .= "💡 *Action Item:* Map your security policies under **RMIT-4.3** and **RMIT-4.4** controls inside our **Control Mapping** screen.";
    } elseif (strpos($q_lower, 'tpa') !== false || strpos($q_lower, 'paynet') !== false) {
        $ai_text = "### 💳 PayNet TPA Compliance Guidance\n\n";
        $ai_text .= "The PayNet Third-Party Acquirer (TPA) guidelines secure transactions and acquirer endpoints across Malaysia.\n\n";
        $ai_text .= "#### Highlights:\n";
        $ai_text .= "- **TPA-1.1 (Governance):** Verify key management, business continuity plans, and vendor audits.\n";
        $ai_text .= "- **TPA-1.2 (Security Standards):** Enforce TLS 1.3 encryption, network segmentation, and quarterly penetration tests.\n\n";
        $ai_text .= "🔍 *Current status:* You have uploaded **{$doc_count} evidence files** to back your PayNet audits. Check the documents workspace to verify controls mapping.";
    } elseif (strpos($q_lower, 'trm') !== false || strpos($q_lower, 'mas') !== false) {
        $ai_text = "### 🇸🇬 MAS TRM Compliance Guidelines\n\n";
        $ai_text .= "The Monetary Authority of Singapore (MAS) Technology Risk Management (TRM) Guidelines outline risk management practices for financial entities.\n\n";
        $ai_text .= "#### Best Practices:\n";
        $ai_text .= "- Enforce two-factor authentication (2FA) / Multi-Factor Authentication (MFA) for administrative access.\n";
        $ai_text .= "- Establish strict data classification structures and database audit logs.\n";
        $ai_text .= "- Conduct annual disaster recovery exercises (BCP/DRP).\n\n";
        $ai_text .= "🛡️ *Risk register alignment:* There are currently **{$risk_count} threat vectors** tracked in the platform. Ensure critical infrastructure risks are linked to TRM controls.";
    } elseif (strpos($q_lower, 'risk') !== false || strpos($q_lower, 'score') !== false) {
        $ai_text = "### ⚠️ Risk Mitigation Advisory\n\n";
        $ai_text .= "Your risk register has **{$risk_count} active records** with an average risk score of **{$avg_risk_score}**.\n\n";
        $ai_text .= "#### Recommended Steps:\n";
        $ai_text .= "1. **Mitigate Critical Threats:** Address risks with scores > 15 (Likelihood $\\times$ Impact).\n";
        $ai_text .= "2. **Align Evidence:** Upload policies or logs verifying controls that offset these risks.\n";
        $ai_text .= "3. **Update Status:** As mitigations are implemented, transition status tags from 'Open' to 'Mitigated'.";
    } else {
        $ai_text = "### 👋 Hello! I am your AI Compliance Assistant.\n\n";
        $ai_text .= "I can analyze your audit status, evidence submissions, and risk profiles in real-time. Here are a few things you can ask me:\n\n";
        $ai_text .= "- 📊 `Generate an Executive Summary` of the platform compliance status.\n";
        $ai_text .= "- 📋 Tell me about `BNM RMiT requirements` for financial compliance.\n";
        $ai_text .= "- 💳 What are the security rules for `PayNet TPA compliance`?\n";
        $ai_text .= "- ⚠️ How should I handle the `risks registered` in the platform?\n\n";
        $ai_text .= "*Note: You can configure a real Gemini API Key in `backend/.env` (using variable name `AI_API_KEY`) to enable conversational AI capabilities.*";
    }
}

// RAG: Append matched document snippets to the final AI response to show retrieval working
if (!empty($matched_docs)) {
    $ai_text .= "\n\n### 📂 Retrieved Evidence Context (RAG)\n";
    $ai_text .= "I found relevant evidence details in your uploaded documents matching your query:\n\n";
    foreach ($matched_docs as $doc) {
        $ai_text .= "📎 **Document:** `{$doc['file_name']}` (Framework: *{$doc['framework']}*, Control: *{$doc['control_code']}*)\n";
        $snippet = substr($doc['extracted_text'], 0, 300) . "...";
        $ai_text .= "> {$snippet}\n\n";
    }
}

send_success("AI response generated.", ["response" => $ai_text]);
?>
