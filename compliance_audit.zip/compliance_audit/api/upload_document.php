<?php
include '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $company_id = $_POST['company_id'];

    $folder = "../uploads/";

    $file_name = time() . "_" . $_FILES['document']['name'];

    $file_path = $folder . $file_name;

    if (move_uploaded_file(
        $_FILES['document']['tmp_name'],
        $file_path
    )) {

        $stmt = $conn->prepare(
            "INSERT INTO documents
            (company_id,file_name,file_path)
            VALUES (?,?,?)"
        );

        $stmt->bind_param(
            "iss",
            $company_id,
            $file_name,
            $file_path
        );

        $stmt->execute();

        echo json_encode([
            "success"=>true
        ]);
    }
}
?>