<?php
// api/company_update.php
require_once '../config/database.php';
require_once '../config/response.php';
require_once '../config/auth.php';

require_admin_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST' && $_SERVER['REQUEST_METHOD'] !== 'PUT') {
    send_error("Invalid request method.", 405);
}

$input = json_decode(file_get_contents("php://input"), true);
$company_id = (int)($input['company_id'] ?? 0);
$company_name = trim($input['company_name'] ?? '');
$industry = trim($input['industry'] ?? '');
$address = trim($input['address'] ?? '');
$contact_email = trim($input['contact_email'] ?? '');
$contact_phone = trim($input['contact_phone'] ?? '');

if ($company_id <= 0 || empty($company_name)) {
    send_error("Company ID and name are required.");
}

// Prepared statement -- the original guide's example used raw
// string interpolation (`SET company_name='ABC'`), which is an
// injection risk. Always bind parameters instead.
$stmt = $conn->prepare("UPDATE companies SET company_name = ?, industry = ?, address = ?, contact_email = ?, contact_phone = ? WHERE company_id = ?");
$stmt->bind_param("sssssi", $company_name, $industry, $address, $contact_email, $contact_phone, $company_id);

if ($stmt->execute()) {
    send_success("Company updated successfully.");
} else {
    send_error("Failed to update company.", 500);
}
