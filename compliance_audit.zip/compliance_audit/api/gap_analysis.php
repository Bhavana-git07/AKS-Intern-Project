<?php
include '../config/database.php';

$assessment_id = $_GET['assessment_id'];

$result = $conn->query(
"SELECT
c.control_code,
c.control_name,
ac.status
FROM assessment_controls ac
JOIN controls c
ON ac.control_id = c.control_id
WHERE ac.assessment_id = $assessment_id"
);

$data = [];

while($row = $result->fetch_assoc()){
    $data[] = $row;
}

echo json_encode($data);
?>